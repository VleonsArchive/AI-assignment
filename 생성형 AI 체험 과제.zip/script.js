const goals = ["알고리즘 향상", "1학기 성적우수", "취뽀하기", "B형취득"];
    const board = document.getElementById("game-board");
    const startBtn = document.getElementById("start-btn");
    const messageBox = document.getElementById("message");
    const timerDisplay = document.getElementById("timer");

    let cards = [];
    let flippedCards = [];
    let lockBoard = false;
    let matchedCount = 0;

    let timer = null;
    let secondsElapsed = 0;

    function formatTime(seconds) {
      const mins = String(Math.floor(seconds / 60)).padStart(2, '0');
      const secs = String(seconds % 60).padStart(2, '0');
      return `${mins}:${secs}`;
    }

    function startTimer() {
      clearInterval(timer);
      secondsElapsed = 0;
      timerDisplay.textContent = "경과 시간: 00:00";
      timer = setInterval(() => {
        secondsElapsed++;
        timerDisplay.textContent = "경과 시간: " + formatTime(secondsElapsed);
      }, 1000);
    }

    function stopTimer() {
      clearInterval(timer);
    }

    function shuffle(array) {
      for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
      }
      return array;
    }

    function createBoard() {
      board.innerHTML = '';
      messageBox.textContent = '';
      matchedCount = 0;
      cards = [];

      const goalPairs = [...goals, ...goals];
      const shuffled = shuffle(goalPairs);

      for (let i = 0; i < 9; i++) {
        if (i === 4) {
          const center = document.createElement('div');
          center.classList.add('center-card');
          center.textContent = '14기 파이팅❤️‍🔥';
          board.appendChild(center);
          continue;
        }

        const goal = shuffled.pop();
        const card = document.createElement('div');
        card.classList.add('card');
        card.dataset.goal = goal;

        const inner = document.createElement('div');
        inner.classList.add('card-inner');

        const front = document.createElement('div');
        front.classList.add('card-front');
        front.textContent = "";

        const back = document.createElement('div');
        back.classList.add('card-back');
        back.textContent = goal;

        inner.appendChild(front);
        inner.appendChild(back);
        card.appendChild(inner);
        board.appendChild(card);

        card.addEventListener('click', () => handleCardClick(card));
        cards.push(card);
      }
    }

    function startGame() {
      createBoard();
      lockBoard = true;
      startTimer(); // 💡 타이머는 카드가 만들어진 직후 바로 시작!

      // 카드 앞면 전체 공개
      setTimeout(() => {
        cards.forEach(card => card.classList.add("flipped"));
      }, 100);

      // 3초 후 다시 가리기
      setTimeout(() => {
        cards.forEach(card => card.classList.remove("flipped"));
        lockBoard = false;
      }, 3000);
    }

    function handleCardClick(card) {
      if (lockBoard || card.classList.contains("flipped") || card.classList.contains("matched")) return;

      card.classList.add("flipped");
      flippedCards.push(card);

      if (flippedCards.length === 2) {
        lockBoard = true;

        const [first, second] = flippedCards;
        if (first.dataset.goal === second.dataset.goal) {
          first.classList.add("matched");
          second.classList.add("matched");
          flippedCards = [];
          matchedCount++;

          if (matchedCount === 4) {
            stopTimer();
            messageBox.textContent = `SSAFY가 목표를 이룰 수 있도록 항상 응원하겠습니다.❤️ (소요 시간: ${formatTime(secondsElapsed)})`;
          }

          lockBoard = false;
        } else {
          setTimeout(() => {
            first.classList.remove("flipped");
            second.classList.remove("flipped");
            flippedCards = [];
            lockBoard = false;
          }, 1000);
        }
      }
    }

    startBtn.addEventListener("click", startGame);